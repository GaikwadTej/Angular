import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BatchService {

  constructor() { }

  GetBatchDetails()
  {
    return[
      {"Name":"Angular","Fees":"INR 1200","Mode":"3 months"},
      {"Name":"Python","Fees":"INR 1400","Mode":"2 months"},
      {"Name":"React","Fees":"INR 1200","Mode":"3.5 months"},
      {"Name":"PHP","Fees":"INR 1700","Mode":"3 months"},
      {"Name":"Linx","Fees":"INR 3200","Mode":"2 months"},
      {"Name":"Java","Fees":"INR 1900","Mode":"3.5 months"},
   
    ]
  }
}
