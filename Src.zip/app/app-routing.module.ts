import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { BatchDetailsComponent } from './batch-details/batch-details.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {path:'',
  redirectTo:'/Home',
  pathMatch:'full'},
{path:'Courses',component:BatchDetailsComponent},
{path:'About',component:AboutComponent},
{path:'Home',component:HomeComponent},
{path:'Feedback',component:FeedbackComponent},
{path:'Register',component:RegisterComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
