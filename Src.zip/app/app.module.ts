import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{AlertModule} from 'ngx-bootstrap/alert'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BatchDetailsComponent } from './batch-details/batch-details.component';
import { BatchService } from './batch.service';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { ControlMessagesComponent} from './control-messages.component'
import { ValidationService } from './validation.service';
import { RegisterComponent } from './register/register.component';


@NgModule({
  declarations: [
    AppComponent,
    BatchDetailsComponent,
    AboutComponent,
    HomeComponent,
    FeedbackComponent,
    ControlMessagesComponent,
    RegisterComponent
  ],
  imports: [ BrowserModule,AppRoutingModule,AlertModule.forRoot(),FormsModule,ReactiveFormsModule],
  providers: [BatchService,ValidationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
