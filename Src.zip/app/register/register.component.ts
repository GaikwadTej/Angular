import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { ValidationService } from '../validation.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent
  {
    public batches=['Linux','Logic Building','Angular','Python','Industrial Project Development']
  
  public str=""
   public event()
   {
     this.str="Registered Successfully"
   }
  
  
  }









